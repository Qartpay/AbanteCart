# AbanteCart
This plugin belongs to Qpay payment gateway.

Qpay_AbanteCart

Introduction

This is the readme file for Qpay Gateway Plugin Integration for AbanteCart v1.2.x based e-Commerce Websites.

The provided Package helps store merchants to redirect customers to the Qpay Gateway when they choose  as their payment method.

The aim of this document is to explain the procedure of installation and configuration of the Plugin on the merchant website.

Installation
Unzip and copy the "Qpay" folder directly to the extensions folder of your website i.e "website_root/extensions/".

Configuration

Log in to your Admin panel and locate the Qpay module in the Payment method section.
Click on Install button to install it.

Configure the required details like Merchant PAY ID, Merchant SALT, Website, Industry Type like ecommerce , Transaction Request URL ,Transaction Response URL etc.
